---
id: home
title: React
permalink: index.html
---

{/* See HomeContent.js */}