import ErrorDecoderPage from './[errorCode]';
export default ErrorDecoderPage;
export {getStaticProps} from './[errorCode]';
