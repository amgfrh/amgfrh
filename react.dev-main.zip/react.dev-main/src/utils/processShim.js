/*
 * Copyright (c) Facebook, Inc. and its affiliates.
 */

// Used in next.config.js to remove the process transitive dependency.
module.exports = {
  env: {},
  cwd() {},
};
